//
//  LoginViewController.swift
//  FinalTask
//
//  Created by Mykhailo Romanovskyi on 21.07.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var user: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var signIn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        user.delegate = self
        password.delegate = self
        disableSignIn()
    }
    
    @IBAction func pressedSignIn(_ sender: UIButton) {
        
        if let user = user.text, let password = password.text, !user.isEmpty, !password.isEmpty {
            LogingToServer(login: user, password: password)
        } else {
            disableSignIn()
        }
    }
}

// MARK: Text Field Delegat
extension LoginViewController: UITextFieldDelegate {
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == user {
            password.becomeFirstResponder()
        } else if let user = user.text, let password = password.text, !user.isEmpty, !password.isEmpty  {
            enableSignIn()
            LogingToServer(login: user, password: password)
        }
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextField.DidEndEditingReason) {
        
        if user.text!.isEmpty || password.text!.isEmpty {
            disableSignIn()
        } else if !signIn.isEnabled {
            enableSignIn()
        }
    }
}

//MARK: Private Functions
extension LoginViewController {
    
    private func disableSignIn() {
        signIn.isEnabled = false
        signIn.alpha = 0.3
    }
    
    private func enableSignIn() {
        signIn.isEnabled = true
        signIn.alpha = 1
    }
    
    private func LogingToServer(login: String, password: String) {
        NetworkManager.shared.logIn(login: login, password: password) { (result) in
            switch result {
            case .success(let codeMessage):
                
                if codeMessage == "OK" {
                    DispatchQueue.main.async {
                        AppDelegate.shared.rootViewController.switchToMainTabBarController()
                    }
                } else {
                    DispatchQueue.main.async {
                        Alert.erroAlertFromServer(vc: self, message: codeMessage)
                    }
                }
            case .failure(_):
                Alert.showAlert(vc: self)
            }
        }
    }
}
