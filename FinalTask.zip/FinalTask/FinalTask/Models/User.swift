//
//  UserM.swift
//  FinalTask
//
//  Created by Mykhailo Romanovskyi on 31.07.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//Модель для пользователя
struct User: Codable {
    let id: String
    let username: String
    let fullName: String
    let avatar: String
    let currentUserFollowsThisUser: Bool
    let currentUserIsFollowedByThisUser: Bool
    let followsCount: Int
    let followedByCount: Int
}
