//
//  AppDelegate.swift
//  Course2FinalTask
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        assembly()
        return true
    }
}

private extension AppDelegate {
    func assembly() {
  //      window = UIWindow(frame: UIScreen.main.bounds)
//        let tabBarController = UITabBarController()
//
//        let feedVC = UINavigationController(rootViewController: FeedViewController(collectionViewLayout: UICollectionViewFlowLayout()))
//        feedVC.tabBarItem.image = #imageLiteral(resourceName: "feed")
//        feedVC.tabBarItem.title = "Feed"
//
//       let profileVC = UINavigationController(rootViewController: ProfileViewController(collectionViewLayout: UICollectionViewFlowLayout()))
//
//        profileVC.tabBarItem.image = #imageLiteral(resourceName: "profile")
//        profileVC.tabBarItem.title = "Profile"
//
//        let newPostVC = UINavigationController(rootViewController: NewPostViewController(collectionViewLayout: UICollectionViewFlowLayout()))
//        newPostVC.tabBarItem.image = #imageLiteral(resourceName: "plus")
//        newPostVC.tabBarItem.title = "New Post"
//
//        tabBarController.viewControllers = [feedVC, newPostVC, profileVC]
//
//        window?.rootViewController = tabBarController
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let loginVC = storyboard.instantiateViewController(withIdentifier: "LoginVC") as! LoginViewController
//        window?.rootViewController = loginVC
//        window?.makeKeyAndVisible()
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = RootViewController()
        window?.makeKeyAndVisible()
        
    }
}

extension AppDelegate {
    static var shared: AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }
    
    var rootViewController: RootViewController {
        return window?.rootViewController as! RootViewController
    }
}
